-- === ГРУППЫ ПОЛЬЗОВАТЕЛЕЙ ===
SELECT * FROM auth_group;

-- === КНИГИ ===
SELECT * FROM main_book;

-- === КАТЕГОРИИ ===
SELECT * FROM main_category;

-- === ПОЛЬЗОВАТЕЛИ ===
SELECT * FROM main_customuser;

-- === БРОНИРОВАНИЯ ===
SELECT * FROM main_booking;

-- === СООБЩЕНИЯ ===
SELECT * FROM main_message;

-- === ГРУППЫ ПОЛЬЗОВАТЕЛЕЙ ===
SELECT * FROM main_customuser_groups;

-- === ПРАВА ПОЛЬЗОВАТЕЛЕЙ ===
SELECT * FROM main_customuser_user_permissions;
